<?php
if(isset($_POST["name"]) && isset($_POST["password"])){
    $file = fopen('data.txt', 'r');
    $good=false;
    while(!feof($file)){
        $line = fgets($file);
        $array = explode(";",$line);
        if($array[0]==$_POST["name"] && $array[1]==$_POST["password"]){
            $good=true;
            break;
        }
    }

    if($good){
        $message="Welcome";
    }else{
        $message="Try again";
    }
    include 'message.html';
fclose($file);
}else{
    include 'login.html';
}
?>