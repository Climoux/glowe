LICENSE TO DOWNLOAD PUBLIC FOLDER GLOWE PACKS (.ZIP) fr-FR

// ------------------------------------------------------------------------------------------------- //
//   _____ _                              _    _           _   _               ______ _ _            //
//  / ____| |                            | |  | |         | | (_)             |  ____(_) |           //
// | |  __| | _____      _____   ______  | |__| | ___  ___| |_ _ _ __   __ _  | |__   _| | ___  ___  //
// | | |_ | |/ _ \ \ /\ / / _ \ |______| |  __  |/ _ \/ __| __| | '_ \ / _` | |  __| | | |/ _ \/ __| //
// | |__| | | (_) \ V  V /  __/          | |  | | (_) \__ \ |_| | | | | (_| | | |    | | |  __/\__ \ //
//  \_____|_|\___/ \_/\_/ \___|          |_|  |_|\___/|___/\__|_|_| |_|\__, | |_|    |_|_|\___||___/ //
//                                                                      __/ |                        //
//                                                                     |___/                         //
// ------------------------------------------------------------------------------------------------- //

INFO : Les droits du dossier publique en revient à son créateur.

DROITS PAR DEFAUTS : 

L'utilisateur ayant télécharger ce dossier publique que l'on appelera : "Le Membre", et l'ayant droit du dossier publique que l'on
appelera : "Le Créateur".

Le Membre a les droits suivant :
- Utiliser le dossier à usage personnel.
- Modifier les fichiers SI besoin.
- Supprimer / Ajouter des fichiers.

Le Membre n'a pas les droits suivant :
- Utiliser le dossier à usage commercial.
- Supprimer / Modifier ce fichier.

Le Créateur a tous les droits sur ses fichiers et ses dossiers (si il y en a). Le Créateur peu donc ajouter un fichier LICENSE
dans la racine de son dossier publique. Si un fichier LICENSE apparaît, ces droits ne sont donc plus valabes, il en revient
au fichier LICENSE. Le Membre doit donc lire OBLIGATOIREMENT ce fichier.

Si une des ces règles est enfreinte par l'utilisateur ("Le Membre") les services Glowe se vera de bannir cet utilisateur de nos service
en empêchant d'y accéder.
---------------------------------------

Fichier modifier le 12/03/2021 à 19:23.

L'équipe Glowe.