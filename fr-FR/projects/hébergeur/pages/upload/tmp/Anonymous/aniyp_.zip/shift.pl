use strict;
use warnings;

my $first = shift;
print "$first\n";
